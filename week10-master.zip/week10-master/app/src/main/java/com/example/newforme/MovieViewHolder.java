package com.example.newforme;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.newforme.R;

/**
 * ViewHolder for movie items in RecyclerView.
 * Holds references to views for efficient recycling.
 */
public class MovieViewHolder extends RecyclerView.ViewHolder{
    private final ImageView posterImageView;
    private final TextView titleTextView;
    private final TextView yearTextView;
    private final TextView genreTextView;

    public MovieViewHolder(@NonNull View itemView) {
        super(itemView);
        posterImageView = itemView.findViewById(R.id.posterImageView);
        titleTextView = itemView.findViewById(R.id.titleTextView);
        yearTextView = itemView.findViewById(R.id.yearTextView);
        genreTextView = itemView.findViewById(R.id.genreTextView);
    }

    /**
     * Binds movie data to the views.
     * @param movie Movie object to display
     */
    public void bind(Movie movie){
        if (movie == null) {
            return;
        }
        // Set title
        titleTextView.setText(movie.getTitle());
        // Set year
        yearTextView.setText(movie.getYear() != null ? String.valueOf(movie.getYear()) : "Unknown");
        // Set genre
        genreTextView.setText(movie.getGenre());

        // 修复：统一使用占位图（实际项目中可扩展为加载真实图片）
        posterImageView.setBackgroundResource(R.drawable.placeholder_poster);
    }
}